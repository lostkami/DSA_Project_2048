﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NotATile : Stack
{
    public Vector2 location;

    public int value;

}
